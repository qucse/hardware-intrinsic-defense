/*
 * ============================================================================
 * DHT11TopModule - Complete System Integration & Display Control
 * ============================================================================
 *
 * PURPOSE:
 *   Top-level system wrapper that integrates all subsystems:
 *   - DHT11 sensor communication (temperature/humidity acquisition)
 *   - BIN2BCD converters (binary ==> BCD encoding � 2)
 *   - 7-segment multiplexed display (4-digit output)
 *   - Display switching logic (temperature <==> humidity every 2.68 seconds)
 *
 * SYSTEM ARCHITECTURE:
 * --------------------
 *
 *     +-----------------------------------------------------------------+
 *     |                       SENSOR ACQUISITION                        |
 *     |  +----------------------------------------------------------+   |
 *     |  |  DHT11 Module                                            |   |
 *     |  |  - 1-wire protocol state machine                         |   |
 *     |  |  - Measures pulse widths (50 MHz timing)                 |   |
 *     |  |  - Shifts in 40-bit data stream                          |   |
 *     |  |  - Extracts temperature (byte #2) & humidity (byte #0)   |   |
 *     |  |                                                          |   |
 *     |  |  Outputs:                                                |   |
 *     |  |    temperature[7:0] (0-50�C typical, 0-255 range)        |   |
 *     |  |    humidity[7:0]    (20-95% typical, 0-255 range)        |   |
 *     |  |    debug_signal ==> LED_CT (blinks during sensor comm)   |   |
 *     |  +----------------------------------------------------------+   |
 *     +-----------------------------------------------------------------+
 *                   \/ binary_Data_to_Display[15:0]
 *                    | [15:8] = temperature
 *                    | [7:0]  = humidity
 *
 *     +-----------------------------------------------------------------+
 *     |                    NUMERIC CONVERSION                           |
 *     |  +----------------------+  +----------------------+             |
 *     |  |  BIN2BCD             |  |  BIN2BCD             |             |
 *     |  |  (Temperature)       |  |  (Humidity)          |             |
 *     |  |                      |  |                      |             |
 *     |  | Input: temp[7:0]     |  | Input: humidity[7:0] |             |
 *     |  | Output:              |  | Output:              |             |
 *     |  |   tens_segment[6:0]  |  |   tens_segment[6:0]  |             |
 *     |  |   units_segment[6:0] |  |   units_segment[6:0] |             |
 *     |  +----------------------+  +----------------------+             |
 *     |        \/                            \/                         |
 *     |   14-bit pattern            14-bit pattern                      |
 *     |   [13:7] = tens             [13:7] = tens                       |
 *     |   [6:0]  = units            [6:0]  = units                      |
 *     +-----------------------------------------------------------------+
 *
 *     +-----------------------------------------------------------------+
 *     |                    DISPLAY SELECTION MUX                        |
 *     |  27-bit clock divider ==> slower_clk (frequency = 50MHz/2^27)   |
 *     |  slower_clk toggles every ~1.34 seconds                         |
 *     |  switchDisp toggles every ~2.68 seconds                         |
 *     |                                                                 |
 *     |  if (switchDisp)                                                |
 *     |    num2disp <== {temp_tens, temp_units, '�', 'C'}               |
 *     |  else                                                           |
 *     |    num2disp <== {humid_tens, humid_units, 'r', 'H'}             |
 *     |                                                                 |
 *     |  num2disp[27:0] = 28-bit packed display data                    |
 *     |    [27:21] digit 3 (leftmost)                                   |
 *     |    [20:14] digit 2                                              |
 *     |    [13:7]  digit 1                                              |
 *     |    [6:0]   digit 0 (rightmost)                                  |
 *     +-----------------------------------------------------------------+
 *                    \/ num2disp[27:0]
 *
 *     +-----------------------------------------------------------------+
 *     |                   DISPLAY MULTIPLEXING                          |
 *     |  +----------------------------------------------------------+   |
 *     |  |  SevenSegmentDisplay Module                              |   |
 *     |  |  - Clock divider: 50 MHz ==> digit selection (3 kHz)     |   |
 *     |  |  - Routes 1 of 4 digit patterns per cycle                |   |
 *     |  |  - Controls anode lines (active LOW)                     |   |
 *     |  |                                                          |   |
 *     |  |  Outputs:                                                |   |
 *     |  |    segment_output[6:0] ==> display segment lines (a-g)   |   |
 *     |  |    anode_output[3:0]   ==> digit select (active LOW)     |   |
 *     |  +----------------------------------------------------------+   |
 *     |                                                                 |
 *     |  Display updates:                                               |
 *     |    Temperature: digits 3,2 = tens,units; digits 1,0 = �,C     	 |	
 *     |    Humidity:    digits 3,2 = tens,units; digits 1,0 = r,H       |
 *     |    Switching: every 2.68 seconds                                |
 *     |    Multiplexing: each digit refreshed ~3 times per second       |
 *     +-----------------------------------------------------------------+
 *                    \/
 *          To 4� 7-segment displays (hardware)
 *
 * SIGNAL FLOW:
 * ------------
 *   wire_of_communication (inout)
 *        \/ (DHT11 sensor)
 *   temperature[7:0], humidity[7:0]
 *        \/
 *   binary_Data_to_Display[15:0] = {temperature, humidity}
 *        \/ (split into two streams)
 *   ==> BIN2BCD #1 ==> temperature_SevenSeg_disp[13:0]
 *   ==> BIN2BCD #2 ==> humidity_SevenSeg_disp[13:0]
 *        \/ (MUX based on switchDisp)
 *   num2disp[27:0] with labels (�, C, r, H)
 *        \/
 *   SevenSegmentDisplay
 *        \/
 *   SevenSegDisp[6:0] (segments)
 *   ANODE[3:0] (digit select)
 *
 * TIMING ANALYSIS:
 * ----------------
 *   Clock: 50 MHz (20 ns per cycle)
 *   
 *   DHT11 sensor read cycle:
 *     - Init: 18 ms (900,000 cycles)
 *     - Data acquisition: ~2-3 ms (40 bits)
 *     - Total: ~20 ms per read
 *     - Repeat: Every 2 seconds minimum (DHT11 spec)
 *
 *   Display refresh:
 *     - 4 digits, each visible for ~327 �s (2^14 cycles)
 *     - Digit refresh rate: 50 MHz / 2^14 =~ 3 kHz (flicker-free)
 *     - Update rate (sensor reads): ~0.5 Hz (every 2 seconds)
 *
 *   Display switching (temperature <==> humidity):
 *     - Clock divider: 27-bit ==> period = 2^27 / 50 MHz =~ 2.68 seconds
 *     - Switching toggles faster_clk every 2.68 seconds
 *     - Each reading visible for ~2.68 seconds
 *
 * OUTPUT DISPLAY EXAMPLES:
 * ------------------------
 *
 *   Case 1: Temperature = 25�C, Humidity = 60%
 *   -----------------------------------------
 *   t=0-2.68s (switchDisp=1):
 *     Digit display: [2][5][�][C]
 *   t=2.68-5.36s (switchDisp=0):
 *     Digit display: [6][0][r][H]
 *   t=5.36-8.04s (switchDisp=1 again):
 *     Back to: [2][5][�][C]
 *
 *   Case 2: Temperature = 0�C, Humidity = 95%
 *   ------------------------------------------
 *   Temperature phase:
 *     Digit display: [0][0][�][C]
 *   Humidity phase:
 *     Digit display: [9][5][r][H]
 *
 * SYMBOL ENCODING:
 * ----------------
 *   Degree symbol (�): 7'b0011100
 *     Displayed in digit 1 when showing temperature
 *
 *   Letter 'C': 7'b0110001
 *     Displayed in digit 0 when showing temperature
 *     Forms uppercase C: ---
 *                        |
 *                        |
 *                        ---
 *
 *   Letter 'r' (relative): 7'b1111000
 *     Displayed in digit 1 when showing humidity
 *     Forms lowercase r
 *
 *   Letter 'H': 7'b1001000
 *     Displayed in digit 0 when showing humidity
 *     Forms uppercase H: |  |
 *                        ----
 *                        |  |
 *
 * DATA PATH CONNECTIONS:
 * ----------------------
 *   DHT11 Module instantiation:
 *     Input:  clk_50mhz <== top-level clk_50mhz
 *     Input:  dht_data <== top-level wire_of_communication (inout)
 *     Output: temperature[7:0] ==> binary_Data_to_Display[15:8]
 *     Output: humidity[7:0] ==> binary_Data_to_Display[7:0]
 *     Output: debug_signal ==> top-level LED_CT
 *
 *   BIN2BCD #1 (Temperature):
 *     Input:  clk_50mhz <== top-level clk_50mhz
 *     Input:  binary_input[7:0] <== binary_Data_to_Display[15:8]
 *     Output: units_segment[6:0] ==> temperature_SevenSeg_disp[6:0]
 *     Output: tens_segment[6:0] ==> temperature_SevenSeg_disp[13:7]
 *
 *   BIN2BCD #2 (Humidity):
 *     Input:  clk_50mhz <== top-level clk_50mhz
 *     Input:  binary_input[7:0] <== binary_Data_to_Display[7:0]
 *     Output: units_segment[6:0] ==> humidity_SevenSeg_disp[6:0]
 *     Output: tens_segment[6:0] ==> humidity_SevenSeg_disp[13:7]
 *
 *   SevenSegmentDisplay:
 *     Input:  clk_50mhz <== top-level clk_50mhz
 *     Input:  numberToDisplay[27:0] <== num2disp[27:0]
 *     Output: segment_output[6:0] ==> top-level SevenSegDisp[6:0]
 *     Output: anode_output[3:0] ==> top-level ANODE[3:0]
 *
 * ============================================================================
 */

module DHT11TopModule( 
    input clk_50mhz,                 // 50 MHz system clock
    inout wire_of_communication,     // 1-wire DHT11 data line
    output [6:0] SevenSegDisp,       // 7-segment pattern output
    output [3:0] ANODE,              // Digit select (active LOW)
    output LED_CT                    // Debug status LED
);

    // ========================================================================
    // INTERNAL SIGNAL DEFINITIONS
    // ========================================================================
    
    // 16-bit bus combining temperature (upper 8 bits) and humidity (lower 8 bits)
    // Format: [15:8] = temperature, [7:0] = humidity
    // Used as input to both BIN2BCD converters
    wire [15:0] binary_Data_to_Display;

    // ========================================================================
    // INSTANTIATION 1: DHT11 SENSOR COMMUNICATION MODULE
    // ========================================================================
    // Handles all 1-wire protocol details: initialization, timing, bit capture
    // Outputs raw 8-bit temperature and humidity readings
    
    DHT11 DHT(
        // Input: System clock and data line
        .clk_50mhz(clk_50mhz),                          // 50 MHz reference
        .dht_data(wire_of_communication),               // 1-wire data line (inout)
        
        // Outputs: Raw sensor data (8-bit integers)
        .temperature(binary_Data_to_Display[15:8]),     // Temp in bits [15:8]
        .humidity(binary_Data_to_Display[7:0]),         // Humidity in bits [7:0]
        
        // Debug output
        .debug_signal(LED_CT)                           // LED blinks during comm
    );

    // ========================================================================
    // INSTANTIATION 2: BCD CONVERTER FOR TEMPERATURE
    // ========================================================================
    // Converts 8-bit temperature (0-255) to two 7-segment digit patterns
    // Output: 14 bits total (7 bits � 2 digits)
    
    wire [13:0] temperature_SevenSeg_disp;  // 2 digits: [13:7]=tens, [6:0]=units
    
    BIN2BCD Decode_Temperature(
        .clk_50mhz(clk_50mhz),                          // System clock
        .binary_input(binary_Data_to_Display[15:8]),    // Temperature input
        .units_segment(temperature_SevenSeg_disp[6:0]), // Units digit pattern
        .tens_segment(temperature_SevenSeg_disp[13:7])  // Tens digit pattern
    );

    // ========================================================================
    // INSTANTIATION 3: BCD CONVERTER FOR HUMIDITY
    // ========================================================================
    // Converts 8-bit humidity (0-255) to two 7-segment digit patterns
    // Output: 14 bits total (7 bits � 2 digits)
    
    wire [13:0] humidity_SevenSeg_disp;  // 2 digits: [13:7]=tens, [6:0]=units
    
    BIN2BCD Decode_Humidity(
        .clk_50mhz(clk_50mhz),                      // System clock
        .binary_input(binary_Data_to_Display[7:0]), // Humidity input
        .units_segment(humidity_SevenSeg_disp[6:0]), // Units digit pattern
        .tens_segment(humidity_SevenSeg_disp[13:7])  // Tens digit pattern
    );

    // ========================================================================
    // DISPLAY SWITCHING LOGIC
    // ========================================================================
    // Toggles between temperature and humidity display every ~2.68 seconds
    
    // 27-bit clock divider for slow frequency
    // Frequency: 50 MHz / 2^27 =~ 0.373 Hz
    // Period: 2^27 / 50 MHz =~ 2.68 seconds
    reg [26:0] div = 27'b0;
    
    always @(posedge clk_50mhz)
        div <= div + 1'b1;  // Increment on each clock cycle
    
    // Extract MSB as slow clock (toggles every period)
    wire slower_clk = div[26];  // 2^27 / (2 * 50MHz) =~ 2.68 seconds per toggle
    
    // Switching control: toggles on every slower_clk rising edge
    reg switchDisp = 1'b0;  // 0 = humidity, 1 = temperature
    
    always @(posedge slower_clk)
        switchDisp <= ~switchDisp;  // Toggle between displays every 2.68s
    
    // ========================================================================
    // MULTIPLEXER: SELECT WHICH READING TO DISPLAY
    // ========================================================================
    // num2disp packs either temperature or humidity along with labels
    
    reg [27:0] num2disp = 28'b0;  // 28-bit packed display data
    
    always @(switchDisp, temperature_SevenSeg_disp, humidity_SevenSeg_disp) begin
        if(switchDisp)
            // Temperature mode: Display [T tens][T units][�][C]
            // Digit 3,2 = temperature, digit 1,0 = degree symbol & 'C'
            num2disp <= {temperature_SevenSeg_disp, 7'b0011100, 7'b0110001};
            //          {tens(7b),units(7b),      degree�(7b), letter_C(7b)}
        else
            // Humidity mode: Display [H tens][H units][r][H]
            // Digit 3,2 = humidity, digit 1,0 = 'r' (relative) & 'H'
            num2disp <= {humidity_SevenSeg_disp, 7'b1111000, 7'b1001000};
            //          {tens(7b),units(7b),    letter_r(7b), letter_H(7b)}
    end

    // ========================================================================
    // INSTANTIATION 4: 7-SEGMENT DISPLAY MULTIPLEXER
    // ========================================================================
    // Multiplexes the 4-digit display at 3 kHz refresh rate
    // Takes 28-bit packed data and cycles through digits
    
    SevenSegmentDisplay Display(
        .clk_50mhz(clk_50mhz),           // 50 MHz reference
        .numberToDisplay(num2disp),      // 28-bit digit patterns to display
        .segment_output(SevenSegDisp),   // Active digit segments [6:0]
        .anode_output(ANODE)             // Digit select control [3:0]
    );

endmodule // DHT11TopModule