/*
 * ==============================================================================
 * DHT11 Module - 1-Wire Temperature/Humidity Sensor Interface
 * ==============================================================================
 *
 * PURPOSE:
 *   Implements DHT11 1-wire protocol using 8-state FSM and 50 MHz timing.
 *   Outputs: temperature[7:0], humidity[7:0], data_ready, debug_signal
 *
 * PROTOCOL TIMING (50 MHz clock = 20 ns per cycle):
 *   18 ms init pulse = 900,000 cycles
 *   Bit detection threshold = 2,500 cycles (50 �s)
 *   Bit '0': 26-28 �s HIGH (~1,300 cycles)
 *   Bit '1': 70 �s HIGH (~3,500 cycles)
 *   Timeout: 1.34 seconds (>67M cycles)
 *
 * FRAME: 40-bit data = 5 bytes
 *   Byte 0 [39:32] = humidity (output)
 *   Byte 1 [31:24] = humidity decimal 
 *   Byte 2 [23:16] = temperature (output)
 *   Byte 3 [15:8]  = temp decimal 
 *   Byte 4 [7:0]   = checksum 
 *
 * STATE MACHINE (8 states):
 *   0x0: START         ==> Pull LOW 18ms
 *   0x1: RELEASE_LINE  ==> Wait for sensor response
 *   0x2: DATA_LOW      ==> Wait for HIGH (bit start)
 *   0x3: DATA_HIGH     ==> Measure HIGH (detect bit value)
 *   0x4: PROCESS_BIT   ==> Shift bit into register
 *   0x5: COMPLETE      ==> Extract data, pulse data_ready
 *   0x6: DELAY         ==> Wait before next read
 *   0x7: RESET         ==> Error recovery
 *
 * TRI-STATE CONTROL:
 *   driving_bus=1, output_value=0 ==> FPGA pulls line LOW
 *   driving_bus=0 ==> line released (pulled HIGH)
 *
 * ==============================================================================
 */

module DHT11(
    input  clk_50mhz,       // 50 MHz input clock
    inout  dht_data,        // Bidirectional data wire to DHT11 sensor
    output reg data_ready,  // Indicates when data transfer is complete
    output reg [7:0] temperature, // Temperature value (integer part)
    output reg [7:0] humidity,    // Humidity value (integer part)
    output debug_signal     // Debug signal, high when FPGA is requesting data
);

    // ========================================================================
    // TRI-STATE BUFFER CONTROL
    // ========================================================================
    // Open-drain control: FPGA drives LOW or releases to pull-up
    
    reg output_value = 1'b0;    // Output value when FPGA drives: 0=LOW, 1=HIGH
    reg driving_bus = 1'b1;     // Enable signal: 1=drive, 0=release (tristate)
    
    // Tri-state buffer: When driving_bus=1 and output_value=0, pulls line LOW
    // When driving_bus=0, releases to pull-up (line floats HIGH)
    assign dht_data = driving_bus ? output_value : 1'bZ;
    
    // Debug signal inverts output_value: HIGH when pulling LOW
    assign debug_signal = ~output_value;

    // ========================================================================
    // TIMING COUNTERS (50 MHz clock, 20 ns per cycle)
    // ========================================================================
    
    // 26-bit counter: measures durations from 0 to ~1.34 seconds
    // 18 ms = 900,000 cycles
    // 1.34 s = 67,000,000 cycles (max timeout)
    reg [25:0] timer_counter = 26'b0;
    reg reset_timer = 1'b1;     // Active LOW reset for timer
    
    // Timer control: increments on clock, resets when reset_timer is LOW
    always @(posedge clk_50mhz, negedge reset_timer)
        if(!reset_timer)        // Reset when reset_timer = 0 (LOW)
            timer_counter <= 26'b0;
        else
            timer_counter <= timer_counter + 1'b1;  // Increment every clock
    
    // ========================================================================
    // TIMING SIGNALS (derived from timer_counter)
    // ========================================================================
    
    // Init pulse complete: 18 ms initialization pulse finished
    // At 50 MHz: 18 ms = 0.018 s � 50,000,000 Hz = 900,000 cycles
    wire init_pulse_complete = (timer_counter == 26'd900000);
    
    // Communication timeout: No activity for 1.34 seconds
    // Safety mechanism: if sensor unresponsive, restart after timeout
    // Max value of 26-bit counter: 2^26 = 67,108,864 cycles ~ 1.34 seconds
    wire comm_timeout = (timer_counter > 26'd67000000);

    // ========================================================================
    // BIT RECEPTION COUNTER
    // ========================================================================
    
    // 6-bit counter: counts bits received (0 to 42, then saturates)
    // DHT11 sends 40 data bits + 2 protocol bits = 42 total
    reg [5:0] bits_received = 6'b0;
    reg reset_bit_counter = 1'b0;  // Active LOW reset
    
    // All bits received: Asserted when bits_received == 42 (0x2A hex)
    wire all_bits_received = (bits_received == 6'h2A);

    // ========================================================================
    // STATE MACHINE DEFINITION (8 states, 4-bit encoding)
    // ========================================================================
    
    // State encodings: 0x0 through 0x7
    localparam STATE_START = 4'h0,      // Initialization: pull LOW for 18 ms
               STATE_RELEASE_LINE = 4'h1,  // Release line, await sensor response
               STATE_DATA_LOW = 4'h2,      // Sensor pulls LOW (start of bit)
               STATE_DATA_HIGH = 4'h3,     // Sensor HIGH (measure pulse width)
               STATE_PROCESS_BIT = 4'h4,   // Capture bit from pulse width
               STATE_COMPLETE = 4'h5,      // All bits received, extract data
               STATE_DELAY = 4'h6,         // Wait before next read cycle
               STATE_RESET = 4'h7;         // Error recovery: restart
    
    reg [3:0] current_state = STATE_START;
    reg capture_bit = 1'b0;  // Signal to shift in a new bit (strobed HIGH 1 cycle)

    // ========================================================================
    // STATE MACHINE TRANSITIONS (combinatorial + sequential)
    // ========================================================================
    
    always @(posedge clk_50mhz) begin
        case(current_state)
            
            // ================================================================
            // STATE_START: Initialize by pulling line LOW for 18 ms
            // ================================================================
            STATE_START: begin
                reset_timer <= 1'b1;        // Timer runs (measuring init pulse)
                driving_bus <= 1'b1;        // FPGA actively drives
                output_value <= 1'b0;       // Output LOW (init signal)
                capture_bit <= 1'b0;        // No bit capture yet
                reset_bit_counter <= 1'b0;  // Keep bit counter reset (not counting yet)
                data_ready <= 1'b0;
                
                // Exit condition: 18 ms elapsed
                if(comm_timeout)
                    // Timeout: no sensor response, error recovery
                    current_state <= STATE_RESET;
                else if(init_pulse_complete)
                    // 18 ms init complete, ready to listen for sensor response
                    current_state <= STATE_RELEASE_LINE;
                else
                    // Still in init phase (holding LOW)
                    current_state <= STATE_START;
            end
            
            // ================================================================
            // STATE_RELEASE_LINE: Release line and wait for sensor response
            // ================================================================
            STATE_RELEASE_LINE: begin
                reset_timer <= 1'b0;        // Stop timing init phase
                driving_bus <= 1'b0;        // Release line (tri-state)
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b0;  // Keep bit counter reset
                data_ready <= 1'b0;
                
                // Exit condition: Sensor pulls line LOW
                if(comm_timeout)
                    current_state <= STATE_RESET;
                else if(dht_data)
                    // Line still HIGH, wait for sensor response
                    current_state <= STATE_RELEASE_LINE;
                else
                    // Line went LOW (sensor responded)
                    current_state <= STATE_DATA_LOW;
            end
            
            // ================================================================
            // STATE_DATA_LOW: Sensor pulls LOW (start of bit transmission)
            // ================================================================
            STATE_DATA_LOW: begin
                reset_timer <= 1'b0;        // Reset timer for next phase measurement
                driving_bus <= 1'b0;        // Line released
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b1;  // Allow bit counter to run
                data_ready <= 1'b0;
                
                // Exit condition: Line goes HIGH (end of LOW phase)
                if(comm_timeout)
                    current_state <= STATE_RESET;
                else if(!dht_data)
                    // Line still LOW, wait for it to rise
                    current_state <= STATE_DATA_LOW;
                else
                    // Line went HIGH (start of HIGH phase)
                    current_state <= STATE_DATA_HIGH;
            end
            
            // ================================================================
            // STATE_DATA_HIGH: Measure HIGH pulse (determines bit value)
            // ================================================================
            STATE_DATA_HIGH: begin
                reset_timer <= 1'b1;        // Start timing the HIGH pulse
                driving_bus <= 1'b0;        // Line released
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b1;  // Allow bit counter to run
                data_ready <= 1'b0;
                
                // Exit condition: Line goes LOW (end of HIGH phase)
                if(comm_timeout)
                    current_state <= STATE_RESET;
                else if(dht_data)
                    // Line still HIGH, continue measuring
                    current_state <= STATE_DATA_HIGH;
                else
                    // Line went LOW (end of HIGH phase, process bit)
                    current_state <= STATE_PROCESS_BIT;
            end
            
            // ================================================================
            // STATE_PROCESS_BIT: Capture and shift bit value
            // ================================================================
            STATE_PROCESS_BIT: begin
                reset_timer <= 1'b1;        // Keep timer running
                driving_bus <= 1'b0;        // Line released
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b1;        // Strobe HIGH for 1 cycle (triggers shift)
                reset_bit_counter <= 1'b1;  // Allow bit counter to increment
                data_ready <= 1'b0;
                
                // Exit condition: All bits received or continue
                if(comm_timeout)
                    current_state <= STATE_RESET;
                else if(all_bits_received)
                    // 42 bits complete (40 data + 2 protocol)
                    current_state <= STATE_COMPLETE;
                else
                    // Continue with next bit
                    current_state <= STATE_DATA_LOW;
            end
            
            // ================================================================
            // STATE_COMPLETE: Extract and output data
            // ================================================================
            STATE_COMPLETE: begin
                reset_timer <= 1'b0;        // Stop measuring
                driving_bus <= 1'b0;        // Line released
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b1;  // Keep bit counter (don't reset yet)
                data_ready <= 1'b1;         // Signal: data is ready (pulses HIGH 1 cycle)
                
                // Always proceed to delay phase
                current_state <= STATE_DELAY;
            end
            
            // ================================================================
            // STATE_DELAY: Wait before next sensor read (DHT11 min 2s interval)
            // ================================================================
            STATE_DELAY: begin
                reset_timer <= 1'b1;        // Timer runs for inter-read delay
                driving_bus <= 1'b0;        // Line released
                output_value <= 1'b1;       // Value irrelevant when not driving
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b0;  // Reset bit counter
                data_ready <= 1'b0;
                
                // Exit condition: Timeout triggers restart
                if(comm_timeout)
                    current_state <= STATE_RESET;
                else
                    // Loop in delay state
                    current_state <= STATE_DELAY;
            end
            
            // ================================================================
            // STATE_RESET: Error recovery and restart
            // ================================================================
            STATE_RESET: begin
                reset_timer <= 1'b0;        // Reset timer
                driving_bus <= 1'b0;        // Release line
                output_value <= 1'b1;       // Value irrelevant
                capture_bit <= 1'b0;
                reset_bit_counter <= 1'b0;  // Reset bit counter
                data_ready <= 1'b0;
                
                // Always restart from beginning
                current_state <= STATE_START;
            end
            
            // ================================================================
            // DEFAULT: Safety fallback (should never occur)
            // ================================================================
            default: current_state <= STATE_START;
        endcase
    end

    // ========================================================================
    // BIT RECEPTION COUNTER (incremented on capture_bit posedge)
    // ========================================================================
    
    always @(posedge capture_bit, negedge reset_bit_counter) begin
        if(!reset_bit_counter)  // Reset when reset_bit_counter is LOW
            bits_received <= 6'b0;
        else
            bits_received <= bits_received + 1'b1;  // Increment on capture_bit pulse
    end

    // ========================================================================
    // DATA SHIFT REGISTER (40-bit accumulator for sensor data)
    // ========================================================================
    
    // Shift register: accumulates the 42 bits received from sensor
    // Format after 42 bits: [39:32]=RH int, [31:24]=RH dec, [23:16]=Temp int, etc.
    reg [39:0] sensor_data = 40'b0;
    
    always @(posedge capture_bit) begin
        // Bit determination based on HIGH pulse width:
        // At 50 MHz: ~50 �s = 2500 cycles
        // If HIGH pulse >= 2500 cycles (50 �s): bit = '1' (long HIGH)
        // If HIGH pulse < 2500 cycles: bit = '0' (short HIGH)
        // Shift left, place new bit at position 0
        sensor_data <= {sensor_data[38:0], (timer_counter >= 26'd2500)};
    end

    // ========================================================================
    // OUTPUT DATA EXTRACTION (when all bits received)
    // ========================================================================
    
    // Extract temperature and humidity from the 40-bit data
    // Byte structure: [39:32]=RH int, [31:24]=RH dec, [23:16]=Temp int, [15:8]=Temp dec, [7:0]=Checksum
    always @(posedge clk_50mhz) begin
        if(all_bits_received) begin
            humidity <= sensor_data[39:32];    // Byte 0: Humidity integer part
            temperature <= sensor_data[23:16]; // Byte 2: Temperature integer part
        end
    end

endmodule // DHT11