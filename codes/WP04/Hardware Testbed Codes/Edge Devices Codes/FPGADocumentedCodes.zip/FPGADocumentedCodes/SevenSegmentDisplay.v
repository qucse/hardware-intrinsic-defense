/*
 * ============================================================================
 * SevenSegmentDisplay Module - 4-Digit 7-Segment Multiplexer
 * ============================================================================
 *
 * PURPOSE:
 *   Multiplexes a 4-digit 7-segment LED display at high refresh rate (3 kHz
 *   per digit) to avoid flicker. Clock divider selects which digit is active;
 *   segment pattern routed from the 28-bit input.
 *
 * INTERFACE:
 *   Inputs:
 *     clk_50mhz      : 50 MHz reference clock
 *     numberToDisplay[27:0] : Packed 28-bit display data
 *       - Bits [27:21] : Digit 3 (leftmost) - 7-bit segment pattern
 *       - Bits [20:14] : Digit 2 - 7-bit segment pattern
 *       - Bits [13:7]  : Digit 1 - 7-bit segment pattern
 *       - Bits [6:0]   : Digit 0 (rightmost) - 7-bit segment pattern
 *
 *   Outputs:
 *     segment_output[6:0] : Currently active digit's segment pattern
 *     anode_output[3:0]   : Digit select (active LOW: 0=ON, 1=OFF)
 *
 * BLOCK DIAGRAM:
 *     clk_50mhz
 *         \/
 *   +---------------------------------+
 *   �  16-bit Clock Divider           �
 *   �  div_counter [15:0]             �
 *   �  Increments on each clk pulse   �
 *   +---------------------------------+
 *         \/
 *   div[15:14] (2 MSBs)
 *         \/
 *   +---------------------------------+
 *   �  4-to-1 Multiplexer             �
 *   �  case(div[15:14])               �
 *   �    00 ==> Digit 0 (rightmost)     �
 *   �    01 ==> Digit 1                 �
 *   �    10 ==> Digit 2                 �
 *   �    11 ==> Digit 3 (leftmost)      �
 *   +---------------------------------+
 *         \/
 *   +---------------------------------+
 *   �  Output Routing                 �
 *   �  - segment_output: pattern from �
 *   �    numberToDisplay[selected_7b] �
 *   �  - anode_output: digit select   �
 *   �    pattern (active LOW)         �
 *   +---------------------------------+
 *         \/
 *   To LED display hardware
 *
 * TIMING ANALYSIS (50 MHz clock, 20 ns per cycle):
 *   Divider overflow period: 2^16 cycles = 65,536 / 50 MHz = 1.31 ms
 *   div[15:14] changes every: 2^14 cycles = 16,384 / 50 MHz = ~327.68 �s
 *   Digit refresh rate: 4 digits / 1.31 ms ~ 3.05 kHz per digit
 *   Critical flicker frequency: ~20 Hz human perception threshold
 *     - At 3 kHz refresh, well above flicker threshold 
 *
 * HARDWARE MAPPING:
 *   segment_output[6:0] ==> FPGA I/O pins to 7-segment common cathode
 *   anode_output[3:0] ==> FPGA I/O pins to 4 anode drive transistors
 *
 *   Anode control encoding (active LOW, common-anode display):
 *     4'b1110 = 0xE : Digit 0 ON  (anodes 1,2,3 OFF)
 *     4'b1101 = 0xD : Digit 1 ON  (anodes 0,2,3 OFF)
 *     4'b1011 = 0xB : Digit 2 ON  (anodes 0,1,3 OFF)
 *     4'b0111 = 0x7 : Digit 3 ON  (anodes 0,1,2 OFF)
 *     4'b1111 = 0xF : All OFF (default/safety)
 *
 * SEGMENT ENCODING (7-bit output):
 *   Bits: [6:0] = g, f, e, d, c, b, a (MSB to LSB)
 *   Display layout (for reference):
 *        aaa
 *       f   b
 *       f   b
 *        ggg
 *       e   c
 *       e   c
 *        ddd
 *
 *   Typical segment patterns (common-anode, 0=ON, 1=OFF):
 *     Digit 0:  7'b0000001  (segments a,b,c,d,e,f ON; g OFF)
 *     Digit 8:  7'b0000000  (all segments ON)
 *     Blank:    7'b1111111  (all segments OFF)
 *
 * STATE TRANSITIONS:
 *   Each clock cycle: div[15:0] increments by 1
 *   Every ~327 �s (div[15:14] rollover): digit selection changes
 *   Combinatorial logic: segment and anode outputs update immediately
 *   upon div[15:14] change (no pipeline delay)
 *
 * INTEGRATION WITH TOP MODULE:
 *   numberToDisplay[27:0] is a 28-bit packed array containing
 *   four 7-bit segment patterns (one per digit).
 *
 *   Example (display "1234"):
 *     Digit 0 (units):    seg1 = 7'b1001111  ==> numberToDisplay[6:0]
 *     Digit 1 (tens):     seg2 = 7'b0010010  ==> numberToDisplay[13:7]
 *     Digit 2 (hundreds): seg3 = 7'b0000110  ==> numberToDisplay[20:14]
 *     Digit 3 (thousands):seg4 = 7'b1001100  ==> numberToDisplay[27:21]
 *
 */

module SevenSegmentDisplay(
    input clk_50mhz, 
    input [27:0] numberToDisplay, //4x 7-seg data cluster
    output reg [6:0] segment_output, 
    output reg [3:0] anode_output
);

    // ========================================================================
    // CLOCK DIVIDER
    // ========================================================================
    // 16-bit counter incremented on every clock cycle
    // Provides slower clock signal for digit selection timing
    reg [15:0] div = 16'b0; // frequency divider 
    
    always @(posedge clk_50mhz)
        div <= div + 1'b1;  // Increments from 0 to 65,535 then wraps
    
    // Extract 2 MSBs for digit selection
    // div[15:14] changes every 2^14 cycles~327.68 �s
    // Provides 4 equally-spaced selection states
    wire slower_clk = div[15]; // Used as slower clk for timing reference
                               // Actual digit selection uses div[15:14]

    // ========================================================================
    // MULTIPLEXER: SELECT ACTIVE DIGIT & ROUTE SEGMENT PATTERN
    // ========================================================================
    // Combinatorial logic: No pipeline delay
    // Updates segment_output and anode_output based on div[15:14]
    
    always @(div[15:14], numberToDisplay) begin
        case(div[15:14])
            
            // ================================================================
            // Digit 0 (rightmost, units position)
            // ================================================================
            2'h0: begin
                anode_output   <= 4'b1110;              // Enable digit 0 only
                                                        // (active LOW: 1110 = digit 0 ON)
                segment_output <= numberToDisplay[6:0]; // Display pattern for digit 0
                                                        // Bits [6:0] of 28-bit input
            end
            
            // ================================================================
            // Digit 1
            // ================================================================
            2'h1: begin
                anode_output   <= 4'b1101;               // Enable digit 1 only
                segment_output <= numberToDisplay[13:7]; // Display pattern for digit 1
                                                         // Bits [13:7] of 28-bit input
            end
            
            // ================================================================
            // Digit 2
            // ================================================================
            2'h2: begin
                anode_output   <= 4'b1011;               // Enable digit 2 only
                segment_output <= numberToDisplay[20:14]; // Display pattern for digit 2
                                                          // Bits [20:14] of 28-bit input
            end
            
            // ================================================================
            // Digit 3 (leftmost, thousands position)
            // ================================================================
            2'h3: begin
                anode_output   <= 4'b0111;               // Enable digit 3 only
                                                         // (active LOW: 0111 = digit 3 ON)
                segment_output <= numberToDisplay[27:21]; // Display pattern for digit 3
                                                          // Bits [27:21] of 28-bit input
            end
            
            // ================================================================
            // Default/Safety (Should never occur in normal operation)
            // ================================================================
            default: begin
                anode_output   <= 4'b1111; // All digits OFF (safe state)
                segment_output <= 7'b1111111; // All segments OFF (blank display)
            end
            
        endcase
    end

endmodule // SevenSegmentDisplay