/*
 * ============================================================================
 * BIN2BCD Module - Binary to Binary-Coded Decimal Conversion
 * ============================================================================
 *
 * PURPOSE:
 *   Converts 8-bit unsigned binary number (0-255) to two 4-bit BCD digits
 *   (tens and units), then feeds each BCD digit to BCD_to_SevenSegment
 *   module for 7-segment display pattern generation. Uses the Double Dabble
 *   algorithm for efficient binary==>BCD conversion.
 *
 * INTERFACE:
 *   Inputs:
 *     clk_50mhz       : 50 MHz reference clock (used for input synchronization)
 *     binary_input[7:0] : Unsigned 8-bit value (0-255)
 *                         Range: 0x00-0xFF
 *                         Typical: temperature 0-50�C, humidity 20-95%
 *
 *   Outputs:
 *     units_segment[6:0] : 7-bit segment pattern for units digit (0-9)
 *     tens_segment[6:0]  : 7-bit segment pattern for tens digit (0-9)
 *
 * ALGORITHM: DOUBLE DABBLE (Shift-and-Add-3)
 * ============================================================================
 *   The Double Dabble algorithm converts binary to BCD by shifting and
 *   correcting. It processes the binary input bit-by-bit, maintaining
 *   invariant: each BCD digit = 9.
 *
 *   PSEUDO-CODE:
 *   ------------
 *   Input: 8-bit binary number
 *   Output: Two 4-bit BCD digits (tens, units)
 *
 *   1. Initialize tens_digit ? 0, units_digit ? 0
 *
 *   2. For each bit of binary input (from MSB=bit7 down to LSB=bit0):
 *
 *      a) Correction Step (ensure each digit < 5 before shift):
 *         if (tens_digit >= 5)
 *            tens_digit ? tens_digit + 3
 *         if (units_digit >= 5)
 *            units_digit ? units_digit + 3
 *
 *      b) Shift Step (left shift all digits, shift in new bit):
 *         carry ? units_digit[3]      // MSB of units will shift to tens
 *         tens_digit ? tens_digit << 1 // Shift left by 1
 *         tens_digit[0] ? carry        // Place carry from units as LSB
 *         
 *         new_bit ? binary_input[current_bit]
 *         units_digit ? units_digit << 1 // Shift left by 1
 *         units_digit[0] ? new_bit     // Place new input bit as LSB
 *
 *   3. Result: tens_digit[3:0] contains tens digit, units_digit[3:0] contains units
 *
 *   EXAMPLE: Converting binary 0x2A (42 decimal) to BCD 4-2:
 *   --------------------------------------------------------
 *   Input: 0x2A = 0b00101010
 *
 *   Initial: tens=0000, units=0000
 *
 *   Bit 7 (0):  No correction needed. Shift: tens=0000, units=0000, new_bit=0
 *   Bit 6 (0):  No correction needed. Shift: tens=0000, units=0000, new_bit=0
 *   Bit 5 (1):  No correction needed. Shift: tens=0000, units=0001, new_bit=1
 *   Bit 4 (0):  No correction needed. Shift: tens=0000, units=0010, new_bit=0
 *   Bit 3 (1):  Correction: units=0010 (<5, no add). Shift: tens=0000, units=0101, new_bit=1
 *   Bit 2 (0):  Correction: units=0101 (=5, add 3==>units=1000). 
 *               Shift: tens=0001, units=0000, new_bit=0
 *   Bit 1 (1):  No correction needed. Shift: tens=0010, units=0001, new_bit=1
 *   Bit 0 (0):  No correction needed. Shift: tens=0100, units=0010, new_bit=0
 *
 *   Final: tens=0100 (4), units=0010 (2) ==> Result: "42" ?
 *
 *
 * VERIFICATION:
 *   -------------
 *   Test vectors:
 *     0 ==> BCD 00 (tens=0, units=0)
 *     5 ==> BCD 05 (tens=0, units=5)
 *     10 ==> BCD 10 (tens=1, units=0)
 *     23 ==> BCD 23 (tens=2, units=3)
 *     42 ==> BCD 42 (tens=4, units=2)
 *     99 ==> BCD 99 (tens=9, units=9)
 *
 * ============================================================================
 */

module BIN2BCD(
    input clk_50mhz, 
    input [7:0] binary_input, 
    output [6:0] units_segment, 
    output [6:0] tens_segment
);

    // ========================================================================
    // INPUT PIPELINE REGISTER
    // ========================================================================
    // Synchronize input to avoid glitches and metastability during conversion
    reg [7:0] registered_binary = 8'b0;
    
    always @(posedge clk_50mhz)
        registered_binary <= binary_input;
    
    // ========================================================================
    // BCD DIGIT REGISTERS
    // ========================================================================
    // Holds tens and units digits during conversion
    // Range per digit: 0-9 (valid BCD)
    reg [3:0] tens_digit;      // Output: tens place (0-9)
    reg [3:0] units_digit;     // Output: units place (0-9)
    
    // Loop counter for Double Dabble algorithm
    integer bit_position;      // Current bit being processed (7 down to 0)

    // ========================================================================
    // DOUBLE DABBLE CONVERSION (Combinatorial Logic)
    // ========================================================================
    // Process each bit of the binary input from MSB (bit 7) to LSB (bit 0)
    
    always @(registered_binary) begin
        
        // Initialize BCD digits to zero at start of conversion
        // These will be shifted and accumulated during the loop
        tens_digit = 4'b0000;
        units_digit = 4'b0000;
    
        // Loop through each bit of the 8-bit binary input
        // Process from MSB (bit_position=7) down to LSB (bit_position=0)
        for(bit_position = 7; bit_position >= 0; bit_position = bit_position - 1) begin
            
            // ================================================================
            // CORRECTION STEP: Add 3 if digit >= 5
            // ================================================================
            // If a BCD digit is >= 5, adding 3 (total +8) ensures that
            // after the left shift, the resulting digit will be valid (<10)
            // This maintains the invariant: each digit < 10 at all times
            
            if(tens_digit >= 5)
                tens_digit = tens_digit + 3;  // Add 3 to tens if >= 5
            
            if(units_digit >= 5)
                units_digit = units_digit + 3;  // Add 3 to units if >= 5
            
            // ================================================================
            // SHIFT STEP: Left shift all digits, shift in new bit
            // ================================================================
            // Shift both BCD digits left by 1 position
            // The MSB of units digit (units_digit[3]) carries to tens
            // A new bit from the input shifts into units_digit[0]
            
            // Shift tens digit left: MSB units (units_digit[3]) becomes new LSB
            tens_digit = tens_digit << 1;       // Shift tens left by 1
            tens_digit[0] = units_digit[3];     // Carry: MSB of units ==> LSB of tens
            
            // Shift units digit left: New input bit becomes new LSB
            units_digit = units_digit << 1;       // Shift units left by 1
            units_digit[0] = registered_binary[bit_position]; // Shift in current input bit
            
            // After shift, each digit could be 0-18 (at most 2x BCD digit + carry)
            // The next iteration's correction step ensures they stay < 20 and < 10
            // after the next shift
        end
    end
    
    // ========================================================================
    // BCD TO 7-SEGMENT CONVERSION
    // ========================================================================
    // Instantiate two decoder modules: one for units, one for tens
    // Each takes a 4-bit BCD digit and outputs 7-bit segment pattern
    
    BCD_to_SevenSegment units_converter(
        .bcd_digit(units_digit),      // 4-bit units digit input (0-9)
        .segment_pattern(units_segment) // 7-bit segment output
    );
    
    BCD_to_SevenSegment tens_converter(
        .bcd_digit(tens_digit),       // 4-bit tens digit input (0-9)
        .segment_pattern(tens_segment)  // 7-bit segment output
    );
    
endmodule // BIN2BCD


/*
 * ============================================================================
 * BCD_to_SevenSegment Module - 4-bit BCD to 7-Segment Decoder
 * ============================================================================
 *
 * PURPOSE:
 *   Translates a single 4-bit BCD digit (0-15) to 7-segment display pattern.
 *   Supports digits 0-9 (standard) and hex A-F (extended, for flexibility).
 *
 * INTERFACE:
 *   Inputs:
 *     bcd_digit[3:0] : 4-bit Binary-Coded Decimal digit (0x0-0xF)
 *                      Valid range: 0-9 (BCD standard), 10-15 (extended)
 *
 *   Outputs:
 *     segment_pattern[6:0] : 7-bit segment control pattern
 *                            Bits: [6:0] = g,f,e,d,c,b,a
 *                            Encoding: 0=segment ON, 1=segment OFF
 *                            (common-anode display active-LOW logic)
 *
 * SEGMENT LAYOUT (Common-Anode 7-Segment Display):
 * -------------------------------------------------
 *   Segment index mapping (bit positions):
 *   Bit 0: a (top horizontal)
 *   Bit 1: b (top-right vertical)
 *   Bit 2: c (bottom-right vertical)
 *   Bit 3: d (bottom horizontal)
 *   Bit 4: e (bottom-left vertical)
 *   Bit 5: f (top-left vertical)
 *   Bit 6: g (middle horizontal)
 *
 * ENCODING (Common-Anode, Inverted Logic):
 * -------------------------------------------
 *   For common-anode displays:
 *     0 = Segment ON  (cathode pulled to ground)
 *     1 = Segment OFF (cathode floating or high)
 *
 *
 * LOOKUP TABLE:
 * -------------
 *   Index  Symbol  Pattern       Description
 *   -------------------------------------------------
 *   0x0    "0"     7'b0000001    Forms hexagon
 *   0x1    "1"     7'b1001111    Right vertical only
 *   0x2    "2"     7'b0010010    No top-right or bottom-left
 *   0x3    "3"     7'b0000110    Two verticals on right
 *   0x4    "4"     7'b1001100    Middle+verticals on right
 *   0x5    "5"     7'b0100100    Inverted S shape
 *   0x6    "6"     7'b0100000    Bottom part + top-left
 *   0x7    "7"     7'b0001111    Top + right verticals
 *   0x8    "8"     7'b0000000    All segments ON
 *   0x9    "9"     7'b0000100    Most segments except bottom-left
 *   0xA    "A"     7'b0001000    Seven-segment display of hex A
 *   0xB    "B"     7'b1100000    Seven-segment display of hex B
 *   0xC    "C"     7'b0110001    Seven-segment display of hex C
 *   0xD    "D"     7'b1000010    Seven-segment display of hex D
 *   0xE    "E"     7'b0110000    Seven-segment display of hex E
 *   0xF    "F"     7'b0111000    Seven-segment display of hex F
 *   default "?"    7'b1111111    All segments OFF (blank)
 *
 * ============================================================================
 */

module BCD_to_SevenSegment(
    input  [3:0] bcd_digit,            // 4-bit BCD digit input (0-15)
    output reg [6:0] segment_pattern   // 7-bit segment pattern output
);

    // ========================================================================
    // COMBINATORIAL LOOKUP TABLE: BCD DIGIT ==> 7-SEGMENT PATTERN
    // ========================================================================
    // Uses case statement to encode all digit patterns
    // Triggered on every change of bcd_digit (no clock needed)
    
    always @(bcd_digit) begin
        case(bcd_digit)
            
            // ==============================================================
            // DECIMAL DIGITS (0-9) - Standard BCD Display
            // ==============================================================
            
            4'h0 : segment_pattern <= 7'b0000001; // Digit "0" - all but g
            4'h1 : segment_pattern <= 7'b1001111; // Digit "1" - b,c only
            4'h2 : segment_pattern <= 7'b0010010; // Digit "2" - a,b,g,e,d
            4'h3 : segment_pattern <= 7'b0000110; // Digit "3" - a,b,g,c,d
            4'h4 : segment_pattern <= 7'b1001100; // Digit "4" - f,g,b,c
            4'h5 : segment_pattern <= 7'b0100100; // Digit "5" - a,f,g,c,d
            4'h6 : segment_pattern <= 7'b0100000; // Digit "6" - a,f,g,e,d,c
            4'h7 : segment_pattern <= 7'b0001111; // Digit "7" - a,b,c,f
            4'h8 : segment_pattern <= 7'b0000000; // Digit "8" - all segments
            4'h9 : segment_pattern <= 7'b0000100; // Digit "9" - all but e
            
            // ==============================================================
            // HEXADECIMAL LETTERS (A-F) - Extended for debugging
            // ==============================================================
            
            4'hA : segment_pattern <= 7'b0001000; // Digit "A" (hex)
            4'hB : segment_pattern <= 7'b1100000; // Digit "B" (hex)
            4'hC : segment_pattern <= 7'b0110001; // Digit "C" (hex)
            4'hD : segment_pattern <= 7'b1000010; // Digit "D" (hex)
            4'hE : segment_pattern <= 7'b0110000; // Digit "E" (hex)
            4'hF : segment_pattern <= 7'b0111000; // Digit "F" (hex)
            
            // ==============================================================
            // DEFAULT (Should never occur with valid BCD, but safe default)
            // ==============================================================
            default : segment_pattern <= 7'b1111111; // All segments OFF (blank)
        endcase
    end

endmodule // BCD_to_SevenSegment